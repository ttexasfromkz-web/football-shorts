// Generates the voiceover (free Microsoft Edge TTS) from the sentences written in data/video.json.
// If something goes wrong (no internet etc.) the video is still rendered, just without voice.
import { MsEdgeTTS, OUTPUT_FORMAT } from "msedge-tts";
import { readFileSync, writeFileSync, mkdirSync, readdirSync, rmSync } from "node:fs";
import { join } from "node:path";

const data = JSON.parse(readFileSync(process.env.DATA || "data/video.json", "utf8"));
const VOICE = process.env.VOICE || data.voice?.name || "kk-KZ-DauletNeural";
const outDir = "public/voice";
const ordered = [...data.items].reverse(); // countdown: last place -> 1st

const lines = [
  { file: "intro.mp3", text: data.voice.intro },
  ...ordered.map((t, i) => ({ file: `card-${i}.mp3`, text: t.voice })),
  { file: "outro.mp3", text: data.voice.outro },
];

async function synth(tts, text) {
  const { audioStream } = await tts.toStream(text);
  const chunks = [];
  for await (const chunk of audioStream) chunks.push(chunk);
  return Buffer.concat(chunks);
}

const clean = () => {
  mkdirSync(outDir, { recursive: true });
  for (const f of readdirSync(outDir)) if (f.endsWith(".mp3") || f === "durations.json") rmSync(join(outDir, f));
};

try {
  clean();
  const tts = new MsEdgeTTS();
  await tts.setMetadata(VOICE, OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3);

  const durations = {};
  for (const { file, text } of lines) {
    const buf = await synth(tts, text);
    if (buf.length < 1000) throw new Error(`Empty audio for ${file}`);
    writeFileSync(join(outDir, file), buf);
    // MP3 is 48 kbit/s constant bitrate -> length in seconds = bytes * 8 / 48000
    const key = file.replace(".mp3", "");
    durations[key] = Math.round(((buf.length * 8) / 48000) * 100) / 100;
    console.log(`voice ok: ${file} (${durations[key]}s)`);
  }
  writeFileSync(join(outDir, "durations.json"), JSON.stringify(durations, null, 2));
  console.log("Voiceover ready.");
} catch (err) {
  console.warn("\n⚠ Voiceover failed:", err?.message || err);
  console.warn("The video will be rendered WITHOUT voice. Check your internet and run `npm run voice` again.\n");
  clean();
}
