// Generates English voiceover (free Microsoft Edge TTS) for every card.
// If something goes wrong (no internet etc.) the video is still rendered, just without voice.
import { MsEdgeTTS, OUTPUT_FORMAT } from "msedge-tts";
import { readFileSync, writeFileSync, mkdirSync, readdirSync, rmSync } from "node:fs";
import { join } from "node:path";

const VOICE = process.env.VOICE || "en-US-AndrewNeural";
const dataFile = process.env.DATA || "data/summer-transfers-2026.json";
const outDir = "public/voice";

const data = JSON.parse(readFileSync(dataFile, "utf8"));
const ordered = [...data.transfers].reverse(); // countdown 10 -> 1

const money = (t) => `${t.fee} million ${t.currency === "€" ? "euros" : "pounds"}`;

const lines = [];
lines.push({
  file: "intro.mp3",
  text: `${data.title} ${data.subtitle}. Number one will shock you.`.toLowerCase(),
});
ordered.forEach((t, i) => {
  const tie = data.transfers.filter((x) => x.rank === t.rank).length > 1;
  lines.push({
    file: `card-${i}.mp3`,
    text: `${tie ? "Joint number" : "Number"} ${t.rank}. ${t.player}. ${t.from} to ${t.to}. ${money(t)}.`,
  });
});
lines.push({ file: "outro.mp3", text: "Who is your number one? Comment and follow for more football rankings." });

async function synth(tts, text) {
  const { audioStream } = await tts.toStream(text);
  const chunks = [];
  for await (const chunk of audioStream) chunks.push(chunk);
  return Buffer.concat(chunks);
}

try {
  mkdirSync(outDir, { recursive: true });
  for (const f of readdirSync(outDir)) if (f.endsWith(".mp3")) rmSync(join(outDir, f));

  const tts = new MsEdgeTTS();
  await tts.setMetadata(VOICE, OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3);

  for (const { file, text } of lines) {
    const buf = await synth(tts, text);
    if (buf.length < 1000) throw new Error(`Empty audio for ${file}`);
    writeFileSync(join(outDir, file), buf);
    console.log(`voice ok: ${file}`);
  }
  console.log("Voiceover ready.");
} catch (err) {
  console.warn("\n⚠ Voiceover failed:", err?.message || err);
  console.warn("The video will be rendered WITHOUT voice. Check your internet and run `npm run voice` again.\n");
  for (const f of readdirSync(outDir)) if (f.endsWith(".mp3")) rmSync(join(outDir, f));
}
