export type Transfer = {
  rank: number;
  player: string;
  from: string;
  to: string;
  fee: number;
  currency: string;
  usd: number;
  fromColor: string;
  toColor: string;
};

export type Top10Props = {
  title: string;
  subtitle: string;
  source: string;
  transfers: Transfer[];
};

export const FPS = 30;
export const INTRO = 150; // 5 s
export const CARD = 135; // 4.5 s
export const OUTRO = 90; // 3 s

export const totalFrames = (n: number) => INTRO + n * CARD + OUTRO;
