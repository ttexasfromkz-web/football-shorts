export type Chip = { text: string; color: string };

// One position of the ranking. Works for any topic (transfers, salaries, goals...).
export type Item = {
  rank: number;
  name: string;
  chips: Chip[]; // 1 chip = just a label, 2 chips = "A -> B"
  valuePrefix: string; // e.g. "$", "£", "" 
  value: number; // the big number (counts up)
  sub: string; // small gold line under the number
  colorA: string; // background glow colours
  colorB: string;
  voice: string; // full sentence for the voiceover
};

export type Ui = {
  hook: string;
  outroBefore: string;
  outroGold: string;
  outroAfter: string;
  cta: string;
  million: string; // unit written after the number, e.g. " млн"
};

// seconds of voiceover per part: { intro, "card-0", ..., outro } (written by `npm run voice`)
export type Durations = Record<string, number>;

export type Top10Props = {
  title: string;
  subtitle: string;
  source: string;
  items: Item[];
  ui: Ui;
  durations?: Durations;
};

export const FPS = 30;
export const INTRO = 150; // minimum lengths in frames
export const CARD = 135;
export const OUTRO = 90;

// A part lasts at least `min` frames, and long enough to say the whole voice line + a short pause.
const need = (seconds: number | undefined, min: number, lead: number) =>
  seconds && seconds > 0 ? Math.max(min, Math.ceil(seconds * FPS) + lead + 12) : min;

export type Part = { from: number; duration: number };
export type Layout = { intro: Part; cards: Part[]; outro: Part; total: number };

export const getLayout = (n: number, durations?: Durations): Layout => {
  const introD = need(durations?.intro, INTRO, 4);
  let t = introD;
  const cards: Part[] = [];
  for (let i = 0; i < n; i++) {
    const d = need(durations?.[`card-${i}`], CARD, 8);
    cards.push({ from: t, duration: d });
    t += d;
  }
  const outroD = need(durations?.outro, OUTRO, 4);
  return { intro: { from: 0, duration: introD }, cards, outro: { from: t, duration: outroD }, total: t + outroD };
};
