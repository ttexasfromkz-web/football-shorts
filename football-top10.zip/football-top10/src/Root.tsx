import { Composition } from "remotion";
import data from "../data/summer-transfers-2026.json";
import { Top10 } from "./Top10";
import { FPS, Top10Props, totalFrames } from "./types";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="Top10"
      component={Top10}
      width={1080}
      height={1920}
      fps={FPS}
      durationInFrames={totalFrames(data.transfers.length)}
      defaultProps={data as Top10Props}
      calculateMetadata={({ props }) => ({
        durationInFrames: totalFrames(props.transfers.length),
      })}
    />
  );
};
