import { Composition, staticFile } from "remotion";
import data from "../data/video.json";
import { Top10 } from "./Top10";
import { Durations, FPS, Top10Props, getLayout } from "./types";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="Top10"
      component={Top10}
      width={1080}
      height={1920}
      fps={FPS}
      durationInFrames={getLayout(data.items.length).total}
      defaultProps={data as Top10Props}
      calculateMetadata={async ({ props }) => {
        // If `npm run voice` made durations.json, every card lasts as long as its voice line.
        let durations: Durations | undefined;
        try {
          const res = await fetch(staticFile("voice/durations.json"));
          if (res.ok) durations = (await res.json()) as Durations;
        } catch {
          durations = undefined;
        }
        return {
          durationInFrames: getLayout(props.items.length, durations).total,
          props: { ...props, durations },
        };
      }}
    />
  );
};
