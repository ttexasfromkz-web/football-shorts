import React from "react";
import {
  AbsoluteFill,
  Audio,
  Sequence,
  getStaticFiles,
  interpolate,
  random,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { Item, Top10Props, Ui, getLayout } from "./types";

const FONT = "'Arial Black', Impact, 'Helvetica Neue', Arial, sans-serif";
const GOLD = "#FFD84A";
const MUSIC_VOLUME = 0.5; // 50% of the track; lower it (e.g. 0.3) if the voice is hard to hear

const hasFile = (name: string) => {
  try {
    return getStaticFiles().some((f) => f.name === name);
  } catch {
    return false;
  }
};

const PARTICLES = 30;

const Background: React.FC<{ a: string; b: string }> = ({ a, b }) => {
  const frame = useCurrentFrame();
  const stripeShift = (frame * 0.8) % 320;
  const pulse = 0.5 + 0.5 * Math.sin(frame / 22);
  const sway = Math.sin(frame / 45) * 3;

  return (
    <AbsoluteFill style={{ overflow: "hidden", background: "linear-gradient(180deg,#0c5a27 0%,#14803a 50%,#0a4020 100%)" }}>
      {/* mowed-grass stripes, slowly moving */}
      <AbsoluteFill
        style={{
          top: -320,
          bottom: -320,
          transform: `translateY(${stripeShift}px)`,
          backgroundImage:
            "repeating-linear-gradient(0deg, rgba(255,255,255,0.10) 0px, rgba(255,255,255,0.10) 160px, rgba(0,0,0,0.12) 160px, rgba(0,0,0,0.12) 320px)",
        }}
      />

      {/* pitch markings, slow zoom */}
      <AbsoluteFill style={{ transform: `rotate(-8deg) scale(${1.15 + frame * 0.0004})` }}>
        <svg width="1080" height="1920" viewBox="0 0 1080 1920" style={{ position: "absolute", inset: 0 }}>
          <g fill="none" stroke="rgba(255,255,255,0.30)" strokeWidth="8">
            <circle cx="540" cy="960" r="260" />
            <line x1="-100" y1="960" x2="1180" y2="960" />
            <rect x="190" y="-40" width="700" height="360" />
            <rect x="190" y="1600" width="700" height="360" />
          </g>
          <circle cx="540" cy="960" r="14" fill="rgba(255,255,255,0.25)" />
        </svg>
      </AbsoluteFill>

      {/* club colour glows */}
      <AbsoluteFill
        style={{
          background: `radial-gradient(ellipse 900px 700px at 0% 0%, ${a} 0%, transparent 70%), radial-gradient(ellipse 900px 700px at 100% 100%, ${b} 0%, transparent 70%)`,
          opacity: 0.6 + pulse * 0.25,
        }}
      />

      {/* stadium light beams */}
      <div
        style={{
          position: "absolute",
          top: -200,
          left: 90,
          width: 260,
          height: 1500,
          background: "linear-gradient(180deg, rgba(255,255,255,0.28), rgba(255,255,255,0))",
          transform: `rotate(${-18 + sway}deg)`,
          transformOrigin: "top center",
          filter: "blur(28px)",
          opacity: 0.55 + pulse * 0.25,
        }}
      />
      <div
        style={{
          position: "absolute",
          top: -200,
          right: 90,
          width: 260,
          height: 1500,
          background: "linear-gradient(180deg, rgba(255,255,255,0.28), rgba(255,255,255,0))",
          transform: `rotate(${18 - sway}deg)`,
          transformOrigin: "top center",
          filter: "blur(28px)",
          opacity: 0.55 + (1 - pulse) * 0.25,
        }}
      />

      {/* floating light particles */}
      {Array.from({ length: PARTICLES }).map((_, i) => {
        const x = random(`px-${i}`) * 1080;
        const base = random(`py-${i}`) * 1920;
        const speed = 0.8 + random(`ps-${i}`) * 1.8;
        const size = 6 + random(`pz-${i}`) * 12;
        const y = (((base - frame * speed) % 1920) + 1920) % 1920;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: x,
              top: y,
              width: size,
              height: size,
              borderRadius: "50%",
              background: i % 3 === 0 ? GOLD : "white",
              opacity: 0.18 + random(`po-${i}`) * 0.35,
            }}
          />
        );
      })}

      {/* darkening layer keeps the text readable */}
      <AbsoluteFill style={{ background: "rgba(3,10,6,0.22)" }} />
    </AbsoluteFill>
  );
};

const Intro: React.FC<{ title: string; subtitle: string; hook: string }> = ({ title, subtitle, hook }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t1 = spring({ frame, fps, config: { damping: 12 } });
  const t2 = spring({ frame: frame - 12, fps, config: { damping: 14 } });
  const t3 = spring({ frame: frame - 40, fps, config: { damping: 14 } });
  return (
    <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", fontFamily: FONT, textAlign: "center", padding: 60 }}>
      <Background a="#0a7d3b" b="#0b0d14" />
      <div style={{ transform: `scale(${t1})`, color: "white", fontSize: 120, lineHeight: 1.05 }}>{title}</div>
      <div style={{ transform: `scale(${t2})`, color: GOLD, fontSize: 84, lineHeight: 1.1, marginTop: 30 }}>{subtitle}</div>
      <div style={{ opacity: t3, color: "white", fontSize: 54, marginTop: 70 }}>{hook}</div>
    </AbsoluteFill>
  );
};

const Chip: React.FC<{ name: string; color: string; delay: number }> = ({ name, color, delay }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({ frame: frame - delay, fps, config: { damping: 14 } });
  return (
    <div
      style={{
        transform: `scale(${s})`,
        background: color,
        color: "white",
        fontSize: 46,
        padding: "20px 34px",
        borderRadius: 24,
        border: "4px solid rgba(255,255,255,0.85)",
        textShadow: "0 3px 8px rgba(0,0,0,0.6)",
        minWidth: 250,
        textAlign: "center",
      }}
    >
      {name}
    </div>
  );
};

const Card: React.FC<{ t: Item; tie: boolean; position: number; total: number; duration: number; ui: Ui }> = ({
  t,
  tie,
  position,
  total,
  duration,
  ui,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const rankIn = spring({ frame, fps, config: { damping: 11 } });
  const nameIn = spring({ frame: frame - 6, fps, config: { damping: 14 } });
  const feeIn = spring({ frame: frame - 34, fps, config: { damping: 12 } });
  const count = interpolate(frame, [30, 62], [0, t.value], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const progress = interpolate(frame, [0, duration], [0, 100]);
  const out = interpolate(frame, [duration - 8, duration], [1, 0], { extrapolateLeft: "clamp" });

  return (
    <AbsoluteFill style={{ fontFamily: FONT, opacity: out }}>
      <Background a={t.colorA} b={t.colorB} />
      <AbsoluteFill style={{ alignItems: "center", paddingTop: 230 }}>
        <div
          style={{
            transform: `scale(${rankIn}) rotate(${(1 - rankIn) * -12}deg)`,
            color: GOLD,
            fontSize: 330,
            lineHeight: 1,
            textShadow: "0 10px 30px rgba(0,0,0,0.6)",
          }}
        >
          {tie ? "=" : "#"}
          {t.rank}
        </div>

        <div
          style={{
            transform: `translateY(${(1 - nameIn) * 80}px)`,
            opacity: nameIn,
            color: "white",
            fontSize: t.name.length > 14 ? 92 : 108,
            textAlign: "center",
            padding: "0 50px",
            marginTop: 10,
            lineHeight: 1.05,
            textShadow: "0 6px 20px rgba(0,0,0,0.7)",
          }}
        >
          {t.name}
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 28, marginTop: 70 }}>
          {t.chips.map((c, k) => (
            <React.Fragment key={k}>
              {k > 0 && <div style={{ color: "white", fontSize: 80 }}>→</div>}
              <Chip name={c.text} color={c.color} delay={14 + k * 8} />
            </React.Fragment>
          ))}
        </div>

        <div
          style={{
            transform: `scale(${feeIn})`,
            marginTop: 90,
            color: "white",
            fontSize: 190,
            textShadow: "0 8px 28px rgba(0,0,0,0.7)",
          }}
        >
          {t.valuePrefix}
          {Math.round(count)}
          {ui.million}
        </div>
        <div style={{ opacity: feeIn, color: GOLD, fontSize: 50, marginTop: 4, textAlign: "center", padding: "0 60px" }}>{t.sub}</div>
      </AbsoluteFill>

      {/* progress bar, kept above the Shorts UI zone */}
      <div style={{ position: "absolute", left: 80, right: 80, bottom: 330, height: 14, background: "rgba(255,255,255,0.25)", borderRadius: 7 }}>
        <div style={{ width: `${progress}%`, height: "100%", background: GOLD, borderRadius: 7 }} />
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 360, textAlign: "center", color: "rgba(255,255,255,0.8)", fontSize: 36 }}>
        {position} / {total}
      </div>
    </AbsoluteFill>
  );
};

const Outro: React.FC<{ source: string; ui: Ui }> = ({ source, ui }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({ frame, fps, config: { damping: 12 } });
  return (
    <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", fontFamily: FONT, textAlign: "center", padding: 60 }}>
      <Background a="#0a7d3b" b="#0b0d14" />
      <div style={{ transform: `scale(${s})`, color: "white", fontSize: 110, lineHeight: 1.1 }}>
        {ui.outroBefore}
        <span style={{ color: GOLD }}>{ui.outroGold}</span>
        {ui.outroAfter}
      </div>
      <div style={{ opacity: s, color: GOLD, fontSize: 64, marginTop: 50 }}>{ui.cta}</div>
      <div style={{ opacity: 0.7, color: "white", fontSize: 30, marginTop: 120, fontFamily: "Arial, sans-serif" }}>{source}</div>
    </AbsoluteFill>
  );
};

export const Top10: React.FC<Top10Props> = ({ title, subtitle, source, items, ui, durations }) => {
  // The video counts down: last place -> 1st
  const ordered = [...items].reverse();
  const layout = getLayout(ordered.length, durations);
  const frames = layout.total;

  return (
    <AbsoluteFill style={{ backgroundColor: "#0b0d14" }}>
      <Sequence from={layout.intro.from} durationInFrames={layout.intro.duration}>
        <Intro title={title} subtitle={subtitle} hook={ui.hook} />
      </Sequence>

      {ordered.map((t, i) => {
        const tie = items.filter((x) => x.rank === t.rank).length > 1;
        const part = layout.cards[i];
        return (
          <Sequence key={`${t.rank}-${t.name}`} from={part.from} durationInFrames={part.duration}>
            <Card t={t} tie={tie} position={i + 1} total={ordered.length} duration={part.duration} ui={ui} />
          </Sequence>
        );
      })}

      <Sequence from={layout.outro.from} durationInFrames={layout.outro.duration}>
        <Outro source={source} ui={ui} />
      </Sequence>

      {/* Optional voiceover: files made by `npm run voice` */}
      {hasFile("voice/intro.mp3") && (
        <Sequence from={4} durationInFrames={layout.intro.duration - 4}>
          <Audio src={staticFile("voice/intro.mp3")} />
        </Sequence>
      )}
      {ordered.map((t, i) =>
        hasFile(`voice/card-${i}.mp3`) ? (
          <Sequence key={`a-${t.rank}-${t.name}`} from={layout.cards[i].from + 8} durationInFrames={layout.cards[i].duration - 8}>
            <Audio src={staticFile(`voice/card-${i}.mp3`)} />
          </Sequence>
        ) : null,
      )}
      {hasFile("voice/outro.mp3") && (
        <Sequence from={layout.outro.from + 4} durationInFrames={layout.outro.duration - 4}>
          <Audio src={staticFile("voice/outro.mp3")} />
        </Sequence>
      )}

      {/* Background music: public/music.mp3 (replace the file to change the track) */}
      {hasFile("music.mp3") && (
        <Audio
          src={staticFile("music.mp3")}
          volume={(f) =>
            MUSIC_VOLUME *
            interpolate(f, [frames - 45, frames], [1, 0], {
              extrapolateLeft: "clamp",
              extrapolateRight: "clamp",
            })
          }
        />
      )}
    </AbsoluteFill>
  );
};
