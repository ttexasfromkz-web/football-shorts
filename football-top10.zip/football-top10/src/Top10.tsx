import React from "react";
import {
  AbsoluteFill,
  Audio,
  Sequence,
  getStaticFiles,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { CARD, INTRO, OUTRO, Top10Props, Transfer, totalFrames } from "./types";

const FONT = "'Arial Black', Impact, 'Helvetica Neue', Arial, sans-serif";
const GOLD = "#FFD84A";
const MUSIC_VOLUME = 0.5; // 50% of the track; lower it (e.g. 0.3) if the voice is hard to hear

const hasFile = (name: string) => {
  try {
    return getStaticFiles().some((f) => f.name === name);
  } catch {
    return false;
  }
};

const Background: React.FC<{ a: string; b: string }> = ({ a, b }) => {
  const frame = useCurrentFrame();
  const shift = interpolate(frame, [0, CARD], [0, 40]);
  return (
    <AbsoluteFill
      style={{
        background: `linear-gradient(${150 + shift}deg, ${a} 0%, #0b0d14 55%, ${b} 100%)`,
      }}
    >
      <AbsoluteFill style={{ background: "rgba(5,7,12,0.45)" }} />
    </AbsoluteFill>
  );
};

const Intro: React.FC<Pick<Top10Props, "title" | "subtitle">> = ({ title, subtitle }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t1 = spring({ frame, fps, config: { damping: 12 } });
  const t2 = spring({ frame: frame - 12, fps, config: { damping: 14 } });
  const t3 = spring({ frame: frame - 40, fps, config: { damping: 14 } });
  return (
    <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", fontFamily: FONT, textAlign: "center", padding: 60 }}>
      <Background a="#0a7d3b" b="#0b0d14" />
      <div style={{ transform: `scale(${t1})`, color: "white", fontSize: 120, lineHeight: 1.05 }}>{title}</div>
      <div style={{ transform: `scale(${t2})`, color: GOLD, fontSize: 84, lineHeight: 1.1, marginTop: 30 }}>{subtitle}</div>
      <div style={{ opacity: t3, color: "white", fontSize: 54, marginTop: 70 }}>Number 1 will shock you</div>
    </AbsoluteFill>
  );
};

const Chip: React.FC<{ name: string; color: string; delay: number }> = ({ name, color, delay }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({ frame: frame - delay, fps, config: { damping: 14 } });
  return (
    <div
      style={{
        transform: `scale(${s})`,
        background: color,
        color: "white",
        fontSize: 46,
        padding: "20px 34px",
        borderRadius: 24,
        border: "4px solid rgba(255,255,255,0.85)",
        textShadow: "0 3px 8px rgba(0,0,0,0.6)",
        minWidth: 250,
        textAlign: "center",
      }}
    >
      {name}
    </div>
  );
};

const Card: React.FC<{ t: Transfer; tie: boolean; position: number }> = ({ t, tie, position }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const rankIn = spring({ frame, fps, config: { damping: 11 } });
  const nameIn = spring({ frame: frame - 6, fps, config: { damping: 14 } });
  const feeIn = spring({ frame: frame - 34, fps, config: { damping: 12 } });
  const count = interpolate(frame, [30, 62], [0, t.fee], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const progress = interpolate(frame, [0, CARD], [0, 100]);
  const out = interpolate(frame, [CARD - 8, CARD], [1, 0], { extrapolateLeft: "clamp" });

  return (
    <AbsoluteFill style={{ fontFamily: FONT, opacity: out }}>
      <Background a={t.fromColor} b={t.toColor} />
      <AbsoluteFill style={{ alignItems: "center", paddingTop: 230 }}>
        <div
          style={{
            transform: `scale(${rankIn}) rotate(${(1 - rankIn) * -12}deg)`,
            color: GOLD,
            fontSize: 330,
            lineHeight: 1,
            textShadow: "0 10px 30px rgba(0,0,0,0.6)",
          }}
        >
          {tie ? "=" : "#"}
          {t.rank}
        </div>

        <div
          style={{
            transform: `translateY(${(1 - nameIn) * 80}px)`,
            opacity: nameIn,
            color: "white",
            fontSize: 108,
            textAlign: "center",
            padding: "0 50px",
            marginTop: 10,
            lineHeight: 1.05,
            textShadow: "0 6px 20px rgba(0,0,0,0.7)",
          }}
        >
          {t.player}
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 28, marginTop: 70 }}>
          <Chip name={t.from} color={t.fromColor} delay={14} />
          <div style={{ color: "white", fontSize: 80 }}>→</div>
          <Chip name={t.to} color={t.toColor} delay={22} />
        </div>

        <div
          style={{
            transform: `scale(${feeIn})`,
            marginTop: 90,
            color: "white",
            fontSize: 190,
            textShadow: "0 8px 28px rgba(0,0,0,0.7)",
          }}
        >
          {t.currency}
          {Math.round(count)}M
        </div>
        <div style={{ opacity: feeIn, color: GOLD, fontSize: 56, marginTop: 4 }}>≈ ${t.usd}M</div>
      </AbsoluteFill>

      {/* progress bar, kept above the Shorts UI zone */}
      <div style={{ position: "absolute", left: 80, right: 80, bottom: 330, height: 14, background: "rgba(255,255,255,0.25)", borderRadius: 7 }}>
        <div style={{ width: `${progress}%`, height: "100%", background: GOLD, borderRadius: 7 }} />
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 360, textAlign: "center", color: "rgba(255,255,255,0.8)", fontSize: 36 }}>
        {position} of 10
      </div>
    </AbsoluteFill>
  );
};

const Outro: React.FC<{ source: string }> = ({ source }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const s = spring({ frame, fps, config: { damping: 12 } });
  return (
    <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", fontFamily: FONT, textAlign: "center", padding: 60 }}>
      <Background a="#0a7d3b" b="#0b0d14" />
      <div style={{ transform: `scale(${s})`, color: "white", fontSize: 110, lineHeight: 1.1 }}>
        Who is your <span style={{ color: GOLD }}>#1</span>?
      </div>
      <div style={{ opacity: s, color: GOLD, fontSize: 64, marginTop: 50 }}>Comment + Follow</div>
      <div style={{ opacity: 0.7, color: "white", fontSize: 30, marginTop: 120, fontFamily: "Arial, sans-serif" }}>{source}</div>
    </AbsoluteFill>
  );
};

export const Top10: React.FC<Top10Props> = ({ title, subtitle, source, transfers }) => {
  // The video counts down: 10 -> 1
  const ordered = [...transfers].reverse();
  const n = ordered.length;
  const frames = totalFrames(n);

  return (
    <AbsoluteFill style={{ backgroundColor: "#0b0d14" }}>
      <Sequence from={0} durationInFrames={INTRO}>
        <Intro title={title} subtitle={subtitle} />
      </Sequence>

      {ordered.map((t, i) => {
        const tie = transfers.filter((x) => x.rank === t.rank).length > 1;
        return (
          <Sequence key={t.player} from={INTRO + i * CARD} durationInFrames={CARD}>
            <Card t={t} tie={tie} position={i + 1} />
          </Sequence>
        );
      })}

      <Sequence from={INTRO + n * CARD} durationInFrames={OUTRO}>
        <Outro source={source} />
      </Sequence>

      {/* Optional voiceover: files made by `npm run voice` */}
      {hasFile("voice/intro.mp3") && (
        <Sequence from={4} durationInFrames={INTRO}>
          <Audio src={staticFile("voice/intro.mp3")} />
        </Sequence>
      )}
      {ordered.map((t, i) =>
        hasFile(`voice/card-${i}.mp3`) ? (
          <Sequence key={`a-${t.player}`} from={INTRO + i * CARD + 8} durationInFrames={CARD - 8}>
            <Audio src={staticFile(`voice/card-${i}.mp3`)} />
          </Sequence>
        ) : null,
      )}
      {hasFile("voice/outro.mp3") && (
        <Sequence from={INTRO + n * CARD + 4} durationInFrames={OUTRO - 4}>
          <Audio src={staticFile("voice/outro.mp3")} />
        </Sequence>
      )}

      {/* Background music: public/music.mp3 (replace the file to change the track) */}
      {hasFile("music.mp3") && (
        <Audio
          src={staticFile("music.mp3")}
          loop
          volume={(f) =>
            MUSIC_VOLUME *
            interpolate(f, [frames - 45, frames], [1, 0], {
              extrapolateLeft: "clamp",
              extrapolateRight: "clamp",
            })
          }
        />
      )}
    </AbsoluteFill>
  );
};
